n = int(raw_input())
list=raw_input().split()

cnt = 0

for i in list:
  num = int(i)
  while True:
    if num%2 == 0 or num%3 == 2:
      cnt += 1
      num-=1
    else:
      break

print cnt