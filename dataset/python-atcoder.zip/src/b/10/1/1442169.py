n=int(input())
a=list(map(int,input().split()))

C=0

for i in range(n):
    while True:
        if a[i]%2==0 or a[i]%3==2:
            C=C+1
            a[i] = a[i] - 1
        elif a[i]%2!=0 and a[i]%3!=2:
            break
    
print(C)