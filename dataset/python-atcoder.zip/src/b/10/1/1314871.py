def main():
    N = int(input())
    A = tuple(map(int, input().split()))

    but = [2, 4, 5, 6, 8]
    take = 0
    for n in A:
        while n in but:
            take += 1
            n -= 1

    print(take)

main()
