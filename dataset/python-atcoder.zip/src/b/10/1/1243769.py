import sys

def solve():
    n = int(input())
    a = [int(i) for i in input().split()]

    ans = 0

    for ai in a:
        while ai % 2 == 0 or ai % 3 == 2:
            ans += 1
            ai -= 1

    print(ans)

if __name__ == '__main__':
    solve()