n = int(input())
a = map(int, input().split())

def pluck(ax):
    tmp = 0
    while(ax>0):
        if ax % 2 != 0 and ax % 3 != 2:
            break
        ax -= 1
        tmp += 1  
    return tmp

ans = 0
for ai in a:
    ans += pluck(ai)

print(ans)