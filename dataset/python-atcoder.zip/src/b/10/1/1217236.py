n= int(input())
a = [int(i) for i in input().split()]

count = 0

for i in range(n):
    while a[i]%3==2 or a[i]%2==0 :
        count +=1
        a[i] -= 1

print(count)
