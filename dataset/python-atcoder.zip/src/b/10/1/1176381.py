n = int(input())
a = map(int, input().split())
ans = 0
l = [3, 0, 1, 0, 1, 2]
for i in a:
    ans += l[i % 6]
print(ans)
