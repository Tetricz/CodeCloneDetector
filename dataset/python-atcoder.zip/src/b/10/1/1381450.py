#abc010b
#1010101010#
#1011011011#
#1010001010#
#1 3 7 9

n = int(input())
s = [int(i) for i in input().split()]
count = 0

for i in range(n) :
  if s[i] == 2 or s[i] == 4 or s[i] == 8:
    count = count + 1
  if s[i] == 5 :
    count = count + 2
  if s[i] == 6 :
    count = count + 3

print(count)