n = int(input())
a = input().split()

i = 0
ans = 0
while i < n:
    sheet = int(a[i])
    while sheet > 0:
        if sheet % 2 == 0 or sheet % 3 == 2:
            ans += 1
        else:
            break
        sheet -= 1
    i += 1
print(ans)
