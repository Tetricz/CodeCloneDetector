S = input()
S += "pp"
print(S)