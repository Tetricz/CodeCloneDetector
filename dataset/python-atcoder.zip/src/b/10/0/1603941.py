a = raw_input()
print a+"pp"