S = input()
T = S + 'pp'
print(T)