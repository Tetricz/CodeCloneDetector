a = input()
print(a+'pp')