S=list(input())

S.append("pp")

N=''.join(S)

print(N)