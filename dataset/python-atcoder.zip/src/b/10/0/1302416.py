s = str(input())
ans = s + "pp"
print(ans)