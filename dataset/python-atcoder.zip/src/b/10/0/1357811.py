# coding -*- utf-8 -*-

original_string = raw_input()

print original_string + "pp"