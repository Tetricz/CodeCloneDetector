# -*- coding: utf_8 -*-

"""
AtCoder Begginer Contest
"""

import sys

# get handle
handleName = sys.stdin.readline().rstrip("\n")

# print answer
print(handleName + "pp")

