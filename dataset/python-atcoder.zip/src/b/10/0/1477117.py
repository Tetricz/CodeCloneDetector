S = input()

print(S+"pp")