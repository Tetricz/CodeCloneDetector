def main():
    S = str(input())
    print(S + 'pp')

main()
