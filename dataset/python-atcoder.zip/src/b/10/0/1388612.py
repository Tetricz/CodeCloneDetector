w=input()
w+='pp'
print(w)