s = input()
print (s+'pp')
