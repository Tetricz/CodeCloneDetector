print(str(input()) + "pp")
