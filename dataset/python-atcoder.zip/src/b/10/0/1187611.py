s = str(input())
print(s + "pp")