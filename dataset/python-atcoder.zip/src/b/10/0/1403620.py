n = input()
print (n + "pp")