# -*- coding: utf-8 -*-
import math
# 整数の入力
S = str(raw_input())
#H2 = int(raw_input())
# スペース区切りの整数の入力
#S, T = map(int, raw_input().split())
# 文字列の入力
#s = raw_input()
# 出力
print S + "pp"