# -*- coding:utf-8 -*-
S = input()
print(S+"pp")