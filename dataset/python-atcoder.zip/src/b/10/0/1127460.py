name = raw_input()

print name+'pp'