
print(input() + "pp")