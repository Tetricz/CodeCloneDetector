S = str(input())
ans = S+"pp"

print(str(ans))