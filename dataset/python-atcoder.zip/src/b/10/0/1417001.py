N = input()
print(N + "pp")
