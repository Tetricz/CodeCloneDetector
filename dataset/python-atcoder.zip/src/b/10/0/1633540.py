S = input()+"pp"
print(S)