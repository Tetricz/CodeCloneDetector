name = input()
print(name + 'pp')