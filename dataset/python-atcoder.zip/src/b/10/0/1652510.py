S = str(input())
print(S + str("pp"))