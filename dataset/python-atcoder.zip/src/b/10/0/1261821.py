s = input()
s = s + 'pp'
print(s)