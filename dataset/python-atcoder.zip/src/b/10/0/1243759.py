import sys

def solve():
    s = input()
    ans = s + 'pp'
    print(ans)

if __name__ == '__main__':
    solve()