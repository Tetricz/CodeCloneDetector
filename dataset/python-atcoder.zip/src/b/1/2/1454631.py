from bisect import bisect, bisect_left
round=lambda x:int((x*2+1)//2)

deg, dis = map(int, input().split())

nwse = [
    'N', 'NNE', 'NE', 'ENE',
    'E', 'ESE', 'SE', 'SSE',
    'S', 'SSW', 'SW', 'WSW',
    'W', 'WNW', 'NW', 'NNW'
]

lim = [
    2, 15, 33, 54,
    79, 107, 138, 171,
    207, 244, 284, 326,
    99999
]

dir = nwse[int(((deg*10+1125)/2250)%16)]
dis = round(dis/6)
w = bisect_left(lim, dis)

if w:
    print(dir, w)
else:
    print('C 0')
