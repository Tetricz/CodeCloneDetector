deg_map = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
           "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]
dis_map = [25, 155, 335, 545, 795, 1075, 1385,
           1715, 2075, 2445, 2845, 3265, 999999]

deg, dis = map(int, raw_input().split())
W = 0
while dis_map[W] * 6 <= dis * 10:
    W += 1
if W == 0:
    Dir = "C"
else:
    k = ((deg * 10 + 1125) / 2250) % 16
    Dir = deg_map[k]
print Dir, W
