# -*- coding: utf-8 -*-
#round
round=lambda x:(x*2+1)//2

def direction(deg):
    deg *= 10
    if 0 <= deg < 1124 : return "N"
    if deg < 3375  : return "NNE"
    if deg < 5625  : return "NE"
    if deg < 7875  : return "ENE"
    if deg < 10125 : return "E"
    if deg < 12375 : return "ESE"
    if deg < 14625 : return "SE"
    if deg < 16875 : return "SSE"
    if deg < 19125 : return "S"
    if deg < 21375 : return "SSW"
    if deg < 23625 : return "SW"
    if deg < 25875 : return "WSW"
    if deg < 28125 : return "W"
    if deg < 30375 : return "WNW"
    if deg < 32625 : return "NW"
    if deg < 34875 : return "NNW"
    return "N"

def w(dis):
    wps = dis/60.0 + 0.001
    wps = round(wps*10)/10
    if 0.0 <= wps <= 0.2 : return 0
    if wps <= 1.5  : return 1
    if wps <= 3.3  : return 2
    if wps <= 5.4  : return 3
    if wps <= 7.9  : return 4
    if wps <= 10.7 : return 5
    if wps <= 13.8 : return 6
    if wps <= 17.1 : return 7
    if wps <= 20.7 : return 8
    if wps <= 24.4 : return 9
    if wps <= 28.4 : return 10
    if wps <= 32.6 : return 11
    if 32.7 <= wps : return 12
    return 0

deg, dis = map(int,input().split())
wind = str(w(dis))
direct = "C" if wind == "0" else direction(deg)
print (direct+" "+wind)
