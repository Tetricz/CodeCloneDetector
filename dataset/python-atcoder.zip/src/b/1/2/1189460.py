# C-風力観測
# 問題URL:http://abc001.contest.atcoder.jp/tasks/abc001_3

# Degは風向を示し、本来の角度を 10 倍した整数で与えられる
# Disは 1 分間の風程を示す整数
Deg, Dis = map(int, input().split())
dire = ["NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]
wind = [0.2, 1.5, 3.3, 5.4, 7.9, 10.7, 13.8, 17.1, 20.7, 24.4, 28.4, 32.6]
W = ""
Dir ="" # 風向き
W = 0 #　風力
cnt = 0 # カウンター

power = round((Dis/60) + 0.000001 , 1)

for i in range(1125, 34876, 2250):
    
    if 34876 <=int(Deg*10) or int(Deg*10) < 1125:
        Dir = "N"
        break
    
    if i <= int(Deg*10) < (i+2250):
        Dir = dire[cnt]
        break
    cnt = cnt + 1

for j in range(11):
    if power >= 32.7 :
        W = 12
        break
    
    if wind[j]+0.000001 <= power <= wind[j+1]:
        W = j + 1
        break

if W == 0:
    Dir = "C"

print(Dir , W)