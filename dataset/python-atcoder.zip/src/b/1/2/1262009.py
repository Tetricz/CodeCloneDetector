# -*- coding: utf-8 -*-
# 整数の入力
a, b= map(float, input().split())
a = a * 0.1
b = b * 10 + 0.001
b = round(b / 60, 0)
b = b * 0.1 - 0.001
if b <= 0.2 :
  print ("C", end = ' ')
elif 11.25 <= a < 33.75 :
  print ("NNE", end = ' ')
elif 33.75 <= a < 56.25 :
  print ("NE", end = ' ')
elif 56.25 <= a < 78.75 :
  print ("ENE", end = ' ')
elif 78.75 <= a < 101.25 :
  print ("E", end = ' ')
elif 101.25 <= a < 123.75 :
  print ("ESE", end = ' ')
elif 123.75 <= a < 146.25 :
  print ("SE", end = ' ')
elif 146.25 <= a < 168.75 :
  print ("SSE", end = ' ')
elif 168.25 <= a < 191.25 :
  print ("S", end = ' ')
elif 191.25 <= a < 213.75 :
  print ("SSW", end = ' ')
elif 213.75 <= a < 236.25 :
  print ("SW", end = ' ')
elif 236.25 <= a < 258.75 :
  print ("WSW", end = ' ')
elif 258.75 <= a < 281.25 :
  print ("W", end = ' ')
elif 281.25 <= a < 303.75 :
  print ("WNW", end = ' ')
elif 303.75 <= a < 326.25 :
  print ("NW", end = ' ')
elif 326.25 <= a < 348.75 :
  print ("NNW", end = ' ')
else :
  print ("N", end = ' ')

if b <= 0.2 : print (0)
elif b <= 1.5 : print (1)
elif b <= 3.3 : print (2)
elif b <= 5.4 : print (3)
elif b <= 7.9 : print (4)
elif b <= 10.7 : print (5)
elif b <= 13.8 : print (6)
elif b <= 17.1 : print (7)
elif b <= 20.7 : print (8)
elif b <= 24.4 : print (9)
elif b <= 28.4 : print (10)
elif b <= 32.6 : print (11)
else : print (12)