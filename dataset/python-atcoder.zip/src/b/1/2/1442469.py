round=lambda x:(x*2+1)//2
a,b = list(map(int,input().split()))
l = ['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW']
a = int(((1125+(a*10))/2250)%16)
s = l[a]
if b == 0:
    b=1
b = round((b*10)/60)/10
c = 12
if b <= 32.6:
    c = 11
if b <= 28.4:
    c = 10
if b <= 24.4:
    c = 9
if b <= 20.7:
    c = 8
if b <= 17.1:
    c = 7
if b <= 13.8:
    c = 6
if b <= 10.7:
    c = 5
if b <= 7.9:
    c = 4
if b <= 5.4:
    c = 3
if b <= 3.3:
    c = 2
if b <= 1.5:
    c = 1
if b <= 0.2:
    c = 0

if c == 0:
    s = 'C'

print("{} {}".format(s,c))