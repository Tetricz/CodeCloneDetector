deg,dis = map(int,input().split())
ans_deg=["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW","N"]
ans_dis=[25,155,335,545,795,1075,1385,1715,2075,2445,2845,3265,999999]
i=0
j=0

while dis*10 >=  ans_dis[j]*6:
    j += 1
if j == 0:
    print("C",j)
else:
    while deg * 10 >= 1125 + 2250*i:
        i += 1
    print(ans_deg[i],j)