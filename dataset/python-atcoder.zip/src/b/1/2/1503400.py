m, n = map(int, input().split())
houi = ["NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW", "N", "C"]
deg = m * 10
dis = n
count = 0

if dis < 15:
    count = 16
    ansdis = 0
else:
    d = 1125
    u = 3375
    if deg >= 0 and deg < 1125:
        count = 15
    else:
        while 1:
            if deg >= d and deg < u:
                break
            if d == 34875:
                break
            count += 1
            d += 2250
            u += 2250

    if dis < 93:
        ansdis = 1
    elif dis < 201:
        ansdis = 2
    elif dis < 327:
        ansdis = 3
    elif dis < 477:
        ansdis = 4
    elif dis < 645:
        ansdis = 5
    elif dis < 831:
        ansdis = 6
    elif dis < 1029:
        ansdis = 7
    elif dis < 1245:
        ansdis = 8
    elif dis < 1467:
        ansdis = 9
    elif dis < 1707:
        ansdis = 10
    elif dis < 1959:
        ansdis = 11
    else:
        ansdis = 12

print(houi[count] + " " + str(ansdis))
