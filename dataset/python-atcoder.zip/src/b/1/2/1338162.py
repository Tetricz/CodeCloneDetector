DIR_LIST = ["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW","N"]
POW_LIST = [25,155,335,545,795,1075,1385,1715,2075,2445,2845,3265, 999999]

def main():
	deg, dis = map(int, input().split(" "))
	i = 0
	while deg * 10 >= 1125 + 2250 * i:
		i += 1
	j = 0
	while dis * 10 >= POW_LIST[j] * 6:
		j += 1
	
	if j == 0:
		print('C', j)
	else:
		print(DIR_LIST[i], j)

main()