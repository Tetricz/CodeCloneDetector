import math
 
directions = ['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW']

degree, speed = map(int,input().split())

#風向き
degree *= 10
degree += 1125
if degree >36000:
	degree -= 36000

direction = directions[degree//2250]

#風力
powerLimits = [ 0.2, 1.5, 3.3, 5.4, 7.9, 10.7, 13.8, 17.1, 20.7, 24.4, 28.4, 32.6, 999999]
speed = math.floor(speed/6 + 0.5) / 10 #小数点第二位で四捨五入するためにまず10秒あたりの速度にして小数点以下第一位で四捨五入してから10分の位にする
for i in range(len(powerLimits)):
	if speed <= powerLimits[i]:
		power = i
		break

if power == 0:
	direction = 'C'

print(direction,power)