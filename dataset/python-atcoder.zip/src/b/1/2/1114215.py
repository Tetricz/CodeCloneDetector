import math
from decimal import *
d_names = ["N",
"NNE",
"NE",
"ENE",
"E",
"ESE",
"SE",
"SSE",
"S",
"SSW",
"SW",
"WSW",
"W",
"WNW",
"NW",
"NNW"]


w_ranges = [(0.0, 0.2),
(0.3, 1.5),
(1.6, 3.3),
(3.4, 5.4),
(5.5, 7.9),
(8.0, 10.7),
(10.8, 13.8),
(13.9, 17.1),
(17.2, 20.7),
(20.8, 24.4),
(24.5, 28.4),
(28.5, 32.6),
(32.7, float("inf"))]

w_ranges = map(lambda x: (Decimal(str(x[0])), Decimal(str(x[1]))), w_ranges)

Deg, Dis = map(int, raw_input().split())
Dir = d_names[int(math.floor((float(Deg)+112.5)/3600*16))%16]
Dis = Decimal(Dis)/60
Dis = Dis.quantize(Decimal(".1"), rounding=ROUND_HALF_UP)
for i, r in enumerate(w_ranges):
	l, u = r
	if Dis >= l and Dis <= u:
		W = i
		break;
if W == 0:
	Dir = "C"
print "{} {}".format(Dir, W) 