from bisect import bisect
deg,dis = map(int,input().split())
direc = ["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW","N"]
power = [2,15,33,54,79,107,138,171,207,244,284,326]
for i in range(len(power)):
    power[i] *= 6
    power[i] += 3

degdir = direc[(10*deg+1125)//(36000//16)]
w = bisect(power,dis)
if w == 0:
    degdir = "C"
print(degdir,w)
