lst1 = [x for x in range(1125, 32626, 2250)]
lst2 = ['NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW']
lst3 = [0.2, 1.5, 3.3, 5.4, 7.9, 10.7, 13.8, 17.1, 20.7, 24.4, 28.4, 32.6]


def azimuth_direction(n):
    n = n * 10
    ret = 'N'
    for idx, a in enumerate(lst1):
        if a <= n < a + 2250:
            ret = lst2[idx]
            break
    return ret


def rnd(x, d=1):
    p = 10**d
    return (x*p*2+1) // 2 / p


def force(n):
    ret = 12
    for idx, a in enumerate(lst3):
        if n <= a:
            ret = idx
            break
    return ret

x, y = map(int, input().split(' '))
a = azimuth_direction(x)
b = force(rnd(y / 60.))
if b == 0:
    print('C 0')
else:
    print('{0} {1}'.format(a, b))
