def main():
    Deg, Dis = map(int, input().split())

    w1 = [(0, 0.2), (0.3, 1.5), (1.6, 3.3), (3.4, 5.4), (5.5, 7.9), (8, 10.7), (10.8, 13.8), (13.9, 17.1), (17.2, 20.7), (20.8, 24.4), (24.5, 28.4), (28.5, 32.6)]
    i = 0
    w = 12
    while i < 12:
        w2 = (Dis / 60 * 20 + 1) // 2 / 10
        if w1[i][0] <= w2 <= w1[i][1]:
            w = i
            break
        i += 1

    d1 = ['NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW']
    d2 = 225
    dir = 'N'
    i = 0
    if w == 0:
        dir = 'C'
    else:
        while i < 15:
            if d2 - 112.5 <= Deg < d2 + 112.5:
                dir = d1[i]
                break
            d2 += 225
            i += 1

    print('{} {}'.format(dir, w))

main()
