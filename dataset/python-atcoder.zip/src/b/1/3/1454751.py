n = int(input())

l = [input() for _ in range(n)]
l = sorted(l)
l = [i.split('-') for i in l]

merged = [0] * (60 * 24 // 5)
merged.append(0)

for s, e in l:
    # convert to minutes
    s = int(s[:2]) * 60 + int(s[2:])
    e = int(e[:2]) * 60 + int(e[2:])

    # round
    s -= s % 5
    e += (5 - e % 5) if e % 5 else 0

    s, e = s//5, e//5
    merged[s] += 1
    merged[e] -= 1

s = ''
ans = []
counter = 0
for i, m in enumerate(merged):
    counter += m
    if counter >= 1 and not s:
        s = '%02d%02d' % (i // 12, (i % 12)*5)

    if counter == 0 and s:
        e = '%02d%02d' % ((i) // 12, ((i) % 12)*5)
        ans.append('%s-%s' % (s, e))
        s = ''

print('\n'.join(ans))
