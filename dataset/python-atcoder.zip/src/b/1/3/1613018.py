import math
dp, result = [0]*(12*24+2), []
for s, e in [(int(s[:2])*12+int(s[2:])//5, int(e[:2])*12+math.ceil(int(e[2:])/5)) for _ in [0]*int(input()) for s, e in (input().split("-"),)]:
    dp[s] += 1
    dp[e] -= 1
for i in range(12*24+1):
    dp[i+1] += dp[i]
    if (i == 0 or dp[i-1] <= 0) and dp[i]:
        result.append("%02d%02d"%(i*5//60,(i*5)%60))
    elif (i > 0 and dp[i-1] > 0) and dp[i] == 0:
        result.append("%02d%02d"%(i*5//60,(i*5)%60))
for i in range(0, len(result), 2):
    print("%s-%s"%(result[i], result[i+1]))