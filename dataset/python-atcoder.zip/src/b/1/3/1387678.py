num = int(input())

time_zones = []
for i in range(num):
    time_zone = input()
    start_time = int(time_zone[0:4])
    start_time -= (start_time % 5)

    end_time = int(time_zone[5:9]) + 4
    end_time -= (end_time % 5)
    if end_time % 100 == 60:
        end_time += 40

    time_zones.append([start_time, end_time])

time_zones.sort()

i = 1
while i <len(time_zones):
    if time_zones[i-1][1] >= time_zones[i][0]:
        time_zones[i-1][1] =  max(time_zones[i-1][1] ,time_zones[i][1])
        del time_zones[i]
    else:
        i += 1

for time_zone in time_zones:
    print("{0:04d}-{1:04d}".format(time_zone[0],time_zone[1]))