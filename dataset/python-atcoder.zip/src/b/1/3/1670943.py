# -*- coding: utf-8 -*-
round=lambda x:(x*2+1)//2

n = int(input())
a = []
for i in range(n):
    a.append(list(input().split("-")))

for i,v in enumerate(a):
    a[i][0] = int( v[0][:3] + str( int(v[0][-1])//5*5 ) )
    m = int(v[1][2:3]+"0") + (int(v[1][-1])+ (5-int(v[1][-1])%5)*bool(int(v[1][-1])%5))
    h = int(v[1][:2])
    a[i][1] = int( str(h+m//60) + "{0:02d}".format(m%60) )

a = sorted(a)
result = []
for i in range(len(a)):
    if i == 0:
        result.append(a[i][0])
        result.append(a[i][1])
        continue

    if result[len(result)-1] < a[i][0]:
        result.append(a[i][0])
        result.append(a[i][1])
        continue
    elif a[i][1] > result[len(result)-1]:
         result[len(result)-1] = a[i][1]

for i in range(len(result))[::2]:
    print("{0:04d}".format(result[i]) + "-" +"{0:04d}".format(result[i+1]))
