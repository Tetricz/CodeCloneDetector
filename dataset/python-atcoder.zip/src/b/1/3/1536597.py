def D(N, TIME):
    # 時刻を5分刻みにする
    time = []
    for lst in TIME:
        S_hh = int(lst[0:2])  # 開始時刻(時)
        S_mm = int(lst[2:4])  # 開始時刻(分)
        E_hh = int(lst[5:7])  # 終了時刻(時)
        E_mm = int(lst[7:9])  # 終了時刻(分)
        start = S_hh * 60 + S_mm  # 開始時刻(0時0分からの経過時間(分))
        end = E_hh * 60 + E_mm  # 終了時刻(0時0分からの経過時間(分))
        start -= start % 5  # 丸めた時刻
        end += (5 - (end % 5)) % 5
        time.append([start, end])
    time.sort()  # 開始時刻の早いものソート

    # imos法で行く
    time_part = [0] * 1442  # 1440(1日は1440分)の区間に分けるには1441個の仕切りが必要、番兵として+1
    for lst in time:
        start_index = lst[0]
        end_index = lst[1]
        time_part[start_index] += 1
        time_part[end_index + 1] -= 1
    for i in range(len(time_part) - 1):
        time_part[i + 1] += time_part[i]

    # 1以上の要素が出てきた区間をs,tに詰める(s[i],t[i]が開始-終了)
    f = 0  # 0なら要素に0が来ており、1なら1が来た
    s = []
    t = []
    for i in range(len(time_part)):
        if time_part[i] > 0 and f == 0:
            s.append(i)
            f = 1
        if time_part[i] == 0 and f == 1:
            t.append(i - 1)
            f = 0

    # 開始終了時刻を復元
    rain_time = ''
    for i in range(len(s)):
        s_hh = s[i] // 60
        s_mm = s[i] % 60
        e_hh = t[i] // 60
        e_mm = t[i] % 60
        rain_time += '{0:02d}{1:02d}-{2:02d}{3:02d}\n'.format(
            s_hh, s_mm, e_hh, e_mm)
    rain_time = rain_time[:-1]
    return rain_time

n = int(input())
t = [input() for i in range(n)]
print(D(n,t))