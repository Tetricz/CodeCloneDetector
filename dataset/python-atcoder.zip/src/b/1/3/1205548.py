# D-感雨時刻の整理
# 問題URL:http://abc001.contest.atcoder.jp/tasks/abc001_4
import math
N = int(input()) # N:メモの数
memo = []
for i in range(N):
    memo.append([int(i) for i in input().split("-") ])

# 5分針を揃える
for i in range(N):
    memo[i][0] = memo[i][0] - (memo[i][0]%100)%5
    if (memo[i][1]%100)%5 != 0 :
        memo[i][1] = memo[i][1] + (5-(memo[i][1]%100)%5)
        if memo[i][1] % 100 == 60:
            memo[i][1] = math.ceil(memo[i][1]/100)
            memo[i][1] = memo[i][1] * 100


# メモを降り始めが早い順に整理
memo.sort()
# 重複部分がないかチェックしながら出力
save = memo[0]
for i in range(N-1):
    if save[1] < memo[i+1][0]:
        print( str(save[0]).zfill(4) + "-"  + str(save[1]).zfill(4) )
        save = memo[i+1]
    elif memo[i+1][0] <= save[1] <= memo[i+1][1]:
        save[1] = memo[i+1][1]

#最後に余ったメモを出力
print( str(save[0]).zfill(4) + "-"  + str(save[1]).zfill(4) )


