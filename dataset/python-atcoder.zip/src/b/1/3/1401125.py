import math
n = int(input())

arr = [[0 for j in range(12)] for i in range(25)]

for i in range(n):
    a,b = map(int,input().split("-"))
    st = (a//100)*60+((a%100)-(a%5))
    en = (b//100)*60+((b%100)+(5-b%5)%5)
    arr[st//60][st%60//5]+=1
    arr[(en)//60][(en)%60//5]-=1
    
started = False

score = 0

for i in range(0,1450,5):
    score += arr[i//60][(i%60)//5]
    if score >= 1 and (not started):
        first = (i//60)*100+(i%60)
        started = True
    if score == 0 and started:
        end = (i//60)*100+(i%60)
        started = False
        print("{0:04d}-{1:04d}".format(first,end))