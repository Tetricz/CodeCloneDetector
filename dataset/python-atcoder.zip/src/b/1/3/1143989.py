n=int(raw_input())
se=[raw_input() for _ in xrange(n)]
time=[]
for i in xrange(n):
    s,e=se[i].split('-')
    if int(s[3])>=5:
        s=s[0:3]+'5'
    else:
        s=s[0:3]+'0'
    if e[3]=='0':
        e=e
    elif int(e[3])<=5:
        e=e[0:3]+'5'
    else:
        e=e[0:2]+str(int(e[2])+1)+'0'
        if e[2]=='6':
            if e[1]=='9':
                e=str(int(e[0])+1)+'0'*3
            else:
                e=e[0]+str(int(e[1])+1)+'0'+e[3]

    time.append([s,e])
#print time
time.sort()
ans=[]
start=time[0][0]
end=time[0][1]
i=1
#print time
while i<len(time):
    s,e=time[i]
    if end<s:
        ans.append(start+'-'+end)
        start=s
        end=e
        i+=1
    else:
        while i<len(time):
            s,e=time[i]
            if s>end:
                break
            if end<e:
                end=e
            i+=1
ans.append(start+'-'+end)
for i in xrange(len(ans)):
    print ans[i]