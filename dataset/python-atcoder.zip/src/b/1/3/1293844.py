def hm2t(n): return n/100*60+n%100
def t2hm(n): return "{0:0>2}".format(n/60)+"{0:0>2}".format(n%60)
def ssh(n): return n/5
def esh(n): return (n+4)/5
n=input()
a=[False]*289
for i in xrange(n):
    s,e = map(lambda x:hm2t(x),map(int,raw_input().split("-")))
    for j in xrange(ssh(s),esh(e)): a[j]=True
start=0
while start<288:
    if a[start]:
        end = start+1
        while a[end] and end<289: end += 1;
        print t2hm(start*5)+"-"+t2hm(end*5)
        start = end+1
    else:
        start += 1