n=int(input())
time = [[0 for i in range(13)] for j in range(25)]
for i in range(n):
    a,b =map(int,input().split("-"))
    if a%10 >= 5:
        a-=a%10-5
    else:
        a-=a%10
    if b%10 > 5:
        b+=10-b%10
        if b%100 == 60:
            b+=40
    elif b%10 == 0:
        b=b
    else:
        b+=5-b%10
    time[a//100][a%100//5]+=1
    time[b//100][b%100//5]-=1
flag = 0
temp= 0
for i in range(25):
    for j in range(13):
        temp +=time[i][j]
        if temp >= 1 and flag == 0:
            start=i*100+j*5
            flag = 1
        if temp == 0 and flag ==1:
            end = i*100+j*5
            flag = 0
            print("{0:04d}-{1:04d}".format(start,end))