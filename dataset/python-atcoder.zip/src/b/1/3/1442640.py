def maru(x,f):#0は直前1は直後の5分に丸め
    if int(x%10) > 5:
        if f == 0:
            x = int(x/10) * 10 + 5
        else:
            x = int(x/10) * 10 + 10
    elif 0 < int(x%10) < 5:
        if f == 0:
            x = int(x/10) * 10
        else:
            x = int(x/10) * 10 +5
    return x

def p(x):
    a = int(x/60)
    b = x%60
    return "{:02d}{:02d}".format(a,b)


n = int(input())
l = [0] * (24 * 60 + 10)
for i in range(n):
    a,b = list(map(int,input().split('-')))
    ah = int(a/100)
    am = int(a%100)
    a = maru(ah*60 + am, 0)
    bh = int(b/100)
    bm = int(b%100)
    b = maru(bh*60 + bm ,1)
    l[a] += 1
    l[b+1] -=1

for i in range(1,len(l)):
    l[i] += l[i-1]
f = 0
s =[]
t = []
for i in range(len(l)):
    if l[i] > 0 and f == 0:
        s.append(i)
        f = 1
    if l[i] == 0 and f == 1:
        t.append(i-1)
        f = 0
for i in range(len(s)):
    print("{}-{}".format(p(s[i]),p(t[i])))