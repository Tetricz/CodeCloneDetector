from collections import defaultdict
from itertools import product, groupby
from math import pi
from collections import deque
from bisect import bisect, bisect_left, bisect_right
INF = 10 ** 10


def pre(sh, sm):
    for i in range(5):
        a = sh * 60 + sm - i
        if a % 5 == 0:
            return a


def nex(eh, em):
    for i in range(5):
        a = eh * 60 + em + i
        if a % 5 == 0:
            return a


def main():
    N = int(input())
    memo = [0] * (24 * 60 + 5)
    for _ in range(N):
        S, E = input().split("-")
        sh, sm = int(S[:2]), int(S[2:])
        eh, em = int(E[:2]), int(E[2:])

        s = pre(sh, sm)
        e = nex(eh, em)
        memo[s] += 1
        memo[e] -= 1

    for i in range(len(memo) - 1):
        memo[i + 1] += memo[i]

    rain = False
    for i in range(len(memo)):
        if not rain and memo[i]:
            rain = True
            print("{0:02d}{1:02d}".format(i // 60, i % 60), end="-")
        elif rain and not memo[i]:
            rain = False
            print("{0:02d}{1:02d}".format(i // 60, i % 60))


if __name__ == '__main__':
    main()
