d = [0] * ((24 * 12) + 1)


def upper(v):
    m = int(v)
    if int(v[-1]) > 5:
        m += 10 - int(v[-1])
    elif int(v[-1]) > 0:
        m += 5 - int(v[-1])
    return m // 5


def floor(v):
    m = int(v)
    if int(v[-1]) >= 5:
        m += 5 - int(v[-1])
    else:
        m = int(v[0] + '0')
    return m // 5


for _ in range(int(input())):
    s, e = map(lambda x: (x[:2], x[2:]), input().split('-'))
    d[int(s[0]) * 12 + floor(s[1])] += 1
    d[int(e[0]) * 12 + upper(e[1])] -= 1


def convtime(v):
    h = v // 12
    m = (v % 12) * 5
    return "{:0>2}{:0>2}".format(h, m)


iv = 0
for i in range(len(d)):
    if d[i] > 0:
        if iv == 0:
            print(convtime(i) + "-", end='')

    iv += d[i]
    if d[i] < 0 and iv <= 0:
        print(convtime(i))
