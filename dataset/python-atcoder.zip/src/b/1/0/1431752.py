import sys

A = input()
B = input()
C = int(A) - int(B)

print(C)