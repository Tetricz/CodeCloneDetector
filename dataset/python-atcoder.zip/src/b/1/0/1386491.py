a = int(raw_input())
b = int(raw_input())
print int(a-b)