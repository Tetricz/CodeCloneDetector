A = input()
B = input() 
print A-B