H1 = int(raw_input())
H2 = int(raw_input())
print H1-H2
