# coding: utf-8

h1 = input()
h2 = input()

print h1 - h2
