# 整数の入力
h1 = int(input())
h2 = int(input())
print(str(h1-h2))