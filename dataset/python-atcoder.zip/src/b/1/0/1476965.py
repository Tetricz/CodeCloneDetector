a = int(input().rstrip())
b = int(input().rstrip())
print(a-b)