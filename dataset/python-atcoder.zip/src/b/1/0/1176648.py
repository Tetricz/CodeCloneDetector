# -*- coding: utf-8 -*-
#入力
h1 = int(input())
h2 = int(input())

print(h1-h2)