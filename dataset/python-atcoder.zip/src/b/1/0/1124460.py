h = [int(input()) for _ in range(2)]

print(h[0] - h[1])