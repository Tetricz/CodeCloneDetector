import numpy as np

a = np.zeros(2, dtype = np.int32)
a[0] = input()
a[1] = input()
print(a[0] - a[1])