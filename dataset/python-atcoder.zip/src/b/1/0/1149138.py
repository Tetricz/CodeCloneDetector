n = int(input())
m = int(input())

print(n - m)