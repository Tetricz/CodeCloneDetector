import sys

def solve():
    h1 = int(input())
    h2 = int(input())
    print(h1 - h2)

if __name__ == '__main__':
    solve()