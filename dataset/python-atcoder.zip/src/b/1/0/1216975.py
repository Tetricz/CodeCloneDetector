h1 = input()
h2 = input()

print "%d" % (h1 - h2)