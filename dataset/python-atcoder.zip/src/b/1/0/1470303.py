a=input()
b=input()
print (int(a)-int(b))