h1 = input()
h2 = input()
print str(h1-h2)