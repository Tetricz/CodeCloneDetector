a = int(input())
b = int(input())
ans = a - b
print(ans)