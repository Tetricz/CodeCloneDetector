# -*- coding: utf-8 -*-
# 整数の入力
a = int(input())
b = int(input())
# 出力
print (a-b)