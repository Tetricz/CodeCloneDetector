a, b = map(int, [input(), input()])
print(a - b)