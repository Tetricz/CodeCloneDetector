H = int(input())
h = int(input())

print(H-h)