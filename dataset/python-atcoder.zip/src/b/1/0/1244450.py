a = input()
b = input()
c = a - b
print c
