# -*- coding: utf-8 -*-

# 入力の数値2つ
h1 = int(input())
h2 = int(input())

ans = h1 - h2

print(ans)