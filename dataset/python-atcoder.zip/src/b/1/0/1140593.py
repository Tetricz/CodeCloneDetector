# coding: utf-8

h1 = input()
h2 = input()

print(int(h1) - int(h2))

