h1,h2 = int(input()),int(input())

print(h1-h2)