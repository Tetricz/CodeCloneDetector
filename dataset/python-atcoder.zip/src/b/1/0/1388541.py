Now=int(input())
Before=int(input())

print(Now-Before)