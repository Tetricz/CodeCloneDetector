#testtest
print input()-input()