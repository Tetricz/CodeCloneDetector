H1,H2 = input(),input()
print H1-H2