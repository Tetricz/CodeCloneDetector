# coding: utf-8

#標準入力から値を取得
H1 = int(input())
H2 = int(input())

print(H1-H2)