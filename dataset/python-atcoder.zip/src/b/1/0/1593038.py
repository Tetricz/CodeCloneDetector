x=int(input())
y=int(input())
print(x-y)
