# -*- coding: utf-8 -*-
h = []

for i in range(2):
	h.append(int(input()))

print(h[0]-h[1])