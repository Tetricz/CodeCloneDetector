ans = int(input())
ans -= int(input())
print(ans)