h1 = int(input())
h2 = int(input())

d = h1 - h2

print(d)