a = [input() for i in range(2)]
print(int(a[0])-int(a[1]))