after = int(raw_input())
before = int(raw_input())
print str(after - before)
