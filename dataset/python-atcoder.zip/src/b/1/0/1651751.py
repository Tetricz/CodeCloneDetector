# -*- coding: utf-8 -*-
# input
H1 = int(input())
H2 = int(input())

# solve & output
print(H1 - H2)