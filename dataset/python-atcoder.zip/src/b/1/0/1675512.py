import sys

a = []
for line in sys.stdin:
    a.append(int(line.strip()))
print(a[0] - a[1])