# -*- coding: utf-8 -*-
# 必要なimportを増やす

class Solver(object):

    def run(self):
        h1 = int(input())
        h2 = int(input())
        print(h1-h2)


####################################
# ここからは見ちゃダメ!

### ここにライブラリを記載 ###

if __name__ == '__main__':
    Solver().run()
