# -*- coding: utf-8 -*-

#複数行に1つのint
# n = int(input())
# t = [int(input()) for i in range(n)]

#1 gyou int split
# t = [int(i) for i in input().split()]

n1 = int(input())
n2 = int(input())

print (n1-n2)
