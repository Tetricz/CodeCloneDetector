def A(H1, H2):
    return H1 - H2

H1 = int(input())
H2 = int(input())
print(A(H1,H2))