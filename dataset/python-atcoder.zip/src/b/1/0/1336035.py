H1 = input()
H2 = input()
print int(H1)-int(H2)