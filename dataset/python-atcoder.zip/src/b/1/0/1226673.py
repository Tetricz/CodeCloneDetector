def A():
    h1 = input()
    h2 = input()
    print("{0}".format(int(h1)-int(h2)))

A()