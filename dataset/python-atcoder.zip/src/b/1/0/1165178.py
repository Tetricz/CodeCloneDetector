# -*- coding: utf-8 -*-

def main():
    h1 = int(input())
    h2 = int(input())

    print(h1 - h2)


if __name__ == '__main__':
    main()