H1 = int(input())
H2 = int(input())

a = H1 - H2
print(a)