h1 = input()

h2 = input()

h = int(h1) - int(h2)

print(h)