H1=int(input())
H2=int(input())
print(H1-H2)