# coding: utf-8
a = int(raw_input())
b = int(raw_input())

result = a - b

print(result)