h1 = raw_input()
h2 = raw_input()
print int(h1) - int(h2)
