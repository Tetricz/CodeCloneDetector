h1 = int(raw_input())
h2 = int(raw_input())

print h1 - h2