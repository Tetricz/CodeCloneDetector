N1 = input()
N2 = input()
print(N1-N2)

