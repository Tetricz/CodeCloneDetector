# -*- coding: utf_8 -*-

"""
AtCoder Begginer Contest 001 A
"""

import sys

# get a
H1 = int(sys.stdin.readline().rstrip("\n"))

# get b,c
H2 = int(sys.stdin.readline().rstrip("\n"))

# print answer
print(H1 - H2)