from collections import defaultdict
from itertools import product, groupby
from math import pi
from collections import deque
from bisect import bisect, bisect_left, bisect_right
INF = 10 ** 10


def main():
    H1, H2 = int(input()), int(input())
    print(H1 - H2)


if __name__ == '__main__':
    main()
