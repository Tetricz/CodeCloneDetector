print(int(input())-int(input()))
