H_1 = int(input())
H_2 = int(input())

res = H_1 - H_2

print(res)