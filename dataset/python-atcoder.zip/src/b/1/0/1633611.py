a=int(input())
b=int(input())

c=a-b
print(str(c))