import sys

H1 = int(sys.stdin.readline().strip())
H2 = int(sys.stdin.readline().strip())

dist = H1 - H2

print dist