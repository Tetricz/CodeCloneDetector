# coding: utf-8
a = int(input())
b = int(input())

result = a - b

print(result)