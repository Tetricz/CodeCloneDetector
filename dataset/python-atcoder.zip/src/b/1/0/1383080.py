# coding:utf-8

H1 = input()
H2 = input()

answer = int(H1) - int(H2)

print(answer)