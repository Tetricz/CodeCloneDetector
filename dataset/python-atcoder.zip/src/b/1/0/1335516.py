def seisekitsu(h1,h2):
    return h1-h2

givenH1 = (int)(input())
givenH2 = (int)(input())

print(seisekitsu(givenH1,givenH2))
