a = input()
b = int(input())

a = int(a)

print(a-b)
