# coding: utf-8
def get_ln_inputs():
    return input().split()
 
 
def get_ln_int_inputs():
    return list(map(int, get_ln_inputs()))
 

def main():
    h1 = get_ln_int_inputs()[0]
    h2 = get_ln_int_inputs()[0]
    print(h1 - h2)


main()