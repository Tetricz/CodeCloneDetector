H1 = int(input())
H2 = int(input())

H = H1-H2

print(H)