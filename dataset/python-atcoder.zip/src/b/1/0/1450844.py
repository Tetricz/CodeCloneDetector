# at kengamine peak
print input()-input()