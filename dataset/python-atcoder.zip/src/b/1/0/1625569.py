A = int(input())
B = int(input())

print(A - B)