h1 = int(input())
h2 = int(input())
print("{}".format(h1-h2))