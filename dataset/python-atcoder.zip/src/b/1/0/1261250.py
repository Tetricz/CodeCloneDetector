i=0
j=0

i = int(input())
j = int(input())

print(i-j)
