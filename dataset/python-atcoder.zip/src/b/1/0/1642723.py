#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""001-A"""


import sys


def main():
    """Main function."""
    H1 = int(sys.stdin.readline())
    H2 = int(sys.stdin.readline())

    print(H1 - H2)


if __name__ == '__main__':
    sys.exit(main())
