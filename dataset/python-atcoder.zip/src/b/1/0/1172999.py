import sys

h1 = int(sys.stdin.readline())
h2 = int(sys.stdin.readline())
print (h1-h2)
