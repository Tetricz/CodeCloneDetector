h1 = input()
h2 = input()
print(str(int(h1)-int(h2)))