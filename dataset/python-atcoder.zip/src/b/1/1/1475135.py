# coding:utf-8

km = int(input())/1000

if km < 0.1:
    print("00")
elif 0.1 <= km <= 5:
    print("{:0>2}".format(int(km*10)))
elif 6 <= km <= 30:
    print(int(km+50))
elif 35 <= km <= 70:
    print(int((km-30)/5+80))
elif km > 70:
    print(89)
