m_imp = int(input())
m = m_imp / 1000

if m < 0.1:
    vv = 0
elif 0.1 <= m <= 5:
    vv = m*10
elif 6 <= m <= 30:
    vv = m + 50
elif 35<= m <= 70:
    vv = (m - 30) / 5 + 80
elif 70 < m:
    vv = 89

VV = '{0:02d}'.format(int(vv))

print(VV)