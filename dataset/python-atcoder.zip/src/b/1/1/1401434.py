n=int(input())
if n<100:
    print("%02d"%(0))
elif 100<=n<=5000:
    print("%02d"%(n//100))
elif 6000<=n<=30000:
    print("%02d"%(50+n//1000))
elif 35000<=n<=70000:
    print("%02d"%((((n//1000)-30)//5)+80))
else:
    print(89)