distance_km_int = int(input()) / 1000

if distance_km_int < 0.1: # two digit!
    vv = 0
elif 0.1 <= distance_km_int <= 5:
    vv = distance_km_int * 10
elif 6 <= distance_km_int <= 30:
    vv = distance_km_int + 50
elif 35 <= distance_km_int <= 70: # Attension!
    vv = (distance_km_int - 30) / 5 + 80
elif 70 < distance_km_int:
    vv = 89

print("{0:02d}".format(int(vv)))
