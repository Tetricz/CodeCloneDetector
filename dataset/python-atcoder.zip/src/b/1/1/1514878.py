x = int(input())/1000

ans = ""

if x < 0.1:
    ans = "00"
elif x <= 5:
    y = x*10
    if y < 10:
        ans = "0" + str(y)
    else:
        ans = str(y)
elif x <= 30:
    ans = str(x+50)
elif x <= 70:
    ans = str((x-30)/5 + 80)
elif x > 70:
    ans = str(89)

print(ans.split(".")[0])