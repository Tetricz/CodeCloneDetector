# -*- coding: utf-8 -*-

#複数行に1つのint
# n = int(input())
# t = [int(input()) for i in range(n)]

#1 gyou int split
# t = [int(i) for i in input().split()]

#桁揃え
#"{0:02d}".format(n)
n = int(input())

if n < 100:
    n = 0
if 100 <= n and n <= 5000:
    n = n/100
if 6000 <= n and n <= 30000:
    n = n/1000 + 50
if 35000 <= n and n <= 70000:
    n = (n/1000-30)/5+80
if n > 70000:
    n = 89

print ("{0:02d}".format(int(n)))
