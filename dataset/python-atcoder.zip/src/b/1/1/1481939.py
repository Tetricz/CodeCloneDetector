m = int(input()) / 1000

if m < 0.1:
    print('{0:02.0f}'.format(0))
elif 0.1 <= m <= 5:
    print('{0:02.0f}'.format(m * 10))
elif 6 <= m <= 30:
    print('{0:02.0f}'.format(m + 50))
elif 35 <= m <= 70:
    print('{0:02.0f}'.format((m - 30) / 5 + 80))
else:
    print('{0:02.0f}'.format(89))