# -*- coding: utf-8 -*-
# 整数の入力
a = float(input())
b = float(a * 0.001)
if b < 0.1 :
  print ("00")
elif 0.1 <= b < 1 :
  print ("0" + str(int(b * 10)))
elif 1 <= b <= 5 :
  print (int(b * 10))
elif 6 <= b <= 30 :
  print (int(b + 50))
elif 35 <= b <= 70 :
  print (int((b - 30) / 5 +80))
elif 70 < b :
  print (89)