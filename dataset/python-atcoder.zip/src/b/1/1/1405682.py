# 整数の入力
m = int(input())

if(m < 100):
    vv = 0
elif(m <= 5000):
    vv = m // 100
elif(m >= 6000 and m <= 30000):
    vv = m // 1000 + 50
elif(m >= 35000 and m <= 70000):
    vv = (m // 1000 - 30) // 5 + 80
elif(m > 70000):
    vv = 89

if(vv < 10):
    print('0' + str(vv))
else:
    print(vv)
