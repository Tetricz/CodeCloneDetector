a = int(input())
def main():
	if a < 100:
		print('00')
	elif a <= 5000:
		print('%02d'%(a/100))
	elif a <= 30000:
		print('%02d'%(50+a/1000))
	elif a <= 70000:
		print('%02d'%((a/1000-30)/5+80))
	else:
		print('89')

main()