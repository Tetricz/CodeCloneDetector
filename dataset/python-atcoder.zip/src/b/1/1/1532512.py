import math

def hoge():
    if int(math.log10(m) + 1) == 1:
        output = "0" + str(m)
        print(output)
    else:
        print(m)


m = int(input())
m = m/1000
if m < 0.1:
    print("00")
elif 0.1 <= m and m <= 5:
    m = int(m * 10)
    hoge()
elif 6 <= m and m <= 30:
    m = int(m + 50)
    hoge()
elif 35 <= m and m <= 70:
    m = int((m - 30) / 5 + 80)
    hoge()
elif 70 <= m:
    print(89)

