
m = int(input())
ans = 0
if(m < 100):
    ans = "00"
elif(m <= 5000):
    ans = int(m/100)
    if(ans < 10):
        ans = "0" + str(ans)
elif(m <= 30000):
    ans = int(m/1000)+50
elif(m <= 70000):
    ans = int((int(m/1000)-30)/5)+80
else:
    ans = 89

print(ans)
