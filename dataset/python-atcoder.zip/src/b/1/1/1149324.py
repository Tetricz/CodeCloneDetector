m = int(input()) / 1000

if m < 0.1:
    print("00")
elif m < 1:
    VV = m * 10
    print("0{0}".format(int(VV)))
elif m <= 5:
    VV = m * 10
    print(int(VV))
elif m >= 6 and m <= 30:
    VV = m + 50
    print(int(VV))
elif m >= 35 and m <= 70:
    VV = (m -30) / 5 + 80
    print(int(VV))
elif 70 < m:
    print(89)