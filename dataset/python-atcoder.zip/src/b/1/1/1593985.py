m =int(input())
if m<100:
    print("00")
elif 100 <= m <= 5000:
    s = int(m/100)
    if s<10:
        print("0"+str(s))
    else:
        print(s)
elif 6000 <= m <= 30000:
    print(int((m/1000)+50))
elif 35000 <= m <= 70000:
    a=(((m/1000)-30)/5)+80
    print(int(a))
elif 70000 < m:
    print(int(89))