m = int(input()) / 1000
if m < 0.1:
    vv = 0
elif 0.1 <= m <= 5.0:
    vv = m * 10
elif 6.0 <= m <= 30:
    vv = m + 50
elif 35 <= m <= 70:
    vv = (m - 30)/5 + 80
elif m > 70:
    vv = 89

print("{0:02d}".format(int(vv)))