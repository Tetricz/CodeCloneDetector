m=int(input())/1000

if m < 0.1:
    V = 0
    
elif 0.1<= m <= 5:
    V = m*10

elif 6 <= m <= 30:
    V=m+50
            
elif 35 <= m <= 70:
    V = (m-30)/5+80
                
else:
    V = 89

print ("{:02d}".format(int(V)))
