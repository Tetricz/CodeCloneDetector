b = float(input())/1000
if b<0.1:
    vv = '00'
elif b<=5:
    if b<1:
        vv = '0%s'%int(b*10)
    else:
        vv = '%s'%int(b*10)
elif b<=30:
    vv = '%s'%int(50+b)
elif b<=70:
    vv = '%s'%int((b-30)/5+80)
else:
    vv = '89'

print(vv)
    
    
    
