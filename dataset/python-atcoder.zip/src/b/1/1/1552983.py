M = input()
def calc():
  if M < 100: return 0
  if M <= 5000: return M // 100
  if M <= 30000: return M // 1000 + 50
  if M <= 70000: return (M // 1000 - 30) // 5 + 80
  return 89
print str(calc()).zfill(2)