def vv(m):
	if m < 100:
		return '00'
	elif m <= 5000:
		ans = m / 100
		if ans < 10:
			return '0' + str(ans)
		else:
			return str(ans)
	elif m <= 30000:
		ans = m / 1000 + 50
		return str(ans)
	elif m <= 70000:
		ans = (m / 1000 - 30) / 5 + 80
		return str(ans)
	else:
		return "89"
		
print vv(int(raw_input()))
