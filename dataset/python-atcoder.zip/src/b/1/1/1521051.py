meter = int(input())
if meter < 100:
    VV = "00"
elif 100 <= meter <= 5000:
    VV = str(meter * 10 // 1000).zfill(2)
elif 6000 <= meter <= 30000:
    VV = str(meter // 1000 + 50)
elif 35000 <= meter <= 70000:
    VV = str(((meter // 1000) - 30) // 5 + 80)
else:
    VV = "89"
print(VV)