m=int(input())/1000
a=0
if m>70:
  a=89
elif m>=35:
  a=(m-30)/5+80
elif m>=6:
  a=m+50
elif m>=0.1:
  a=m*10
else:
  a=0
print("{0:02d}".format(int(a)))