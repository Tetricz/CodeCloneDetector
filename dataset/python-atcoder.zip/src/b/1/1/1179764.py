# B-視程の通報
# http://abc001.contest.atcoder.jp/tasks/abc001_2

m = int(input())
km = m /1000 #メートルをキロメートルに変換
VV = 0

# kmの値によってVVを規定
if km < 0.1:
    VV = "00"

elif 0.1 <= km <= 5:
    VV = int(km * 10)
    VV = str(VV).zfill(2)

elif 6 <= km <= 30:
    VV = int(km +50)

elif 35 <= km <= 70:
    VV = int((km - 30) / 5 + 80)

elif 70 < km:
    VV = 89
    
print(VV)