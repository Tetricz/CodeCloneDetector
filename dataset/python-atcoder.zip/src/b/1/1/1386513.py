m = int(raw_input())
w = 0
if m < 100:
  w = 0
elif m <= 5000:
  w = int(m/100)
elif m <= 30000:
  w = int(m/1000 + 50)
elif m <= 70000:
  w = int(((m/1000 - 30) / 5) + 80)
else:
  w = 89
print '%02d' % w 