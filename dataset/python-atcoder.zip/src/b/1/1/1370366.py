m = int( input() )

km = m/1000

if km < 0.1:
    print('00')
elif 0.1 <= km < 1:
    kma = int( 10*km )
    kmas = str( kma )
    print( '0' + kmas )
elif 1 <= int(km) <= 5:
    print( int(10*km) )
elif 6 <= int(km) <= 30:
    print( int(km) + 50 )
elif 35 <= km <= 70:
    kma = int( ( int(km) - 30 ) / 5)+ 80  
    print(kma)
else:
    print(89)
    