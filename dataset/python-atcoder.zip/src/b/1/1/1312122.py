m = int(input())
if m < 100:
    ans = "00"
elif m <= 5000:
    ans = str(int(m / 100))
    if len(ans) < 2:
        ans = "0" + ans
elif m <= 30000:
    ans = str(int(m/1000)+50)
elif m <= 70000:
    ans = str(int((m-30000)/5000+80))
else:
    ans = "89"

print(ans)
