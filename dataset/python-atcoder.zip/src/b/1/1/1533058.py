m = int(input())
M = m/1000

if M < 0.1:
    print("00")
elif 0.1 <= M <= 5:
    M = M * 10
    if M < 10:
        print("0" + str(int(M)))
    else:
        print(int(M))
elif 6 <= M <=30:
    print(int(M+50))
elif 35 <= M <= 70:
    print( int((M-30)/5+80) )
elif 70 < M:
    print(89)