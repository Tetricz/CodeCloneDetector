dis = int(input())
vv = 0
def km2m(num):
    return num*1000

def m2km(num):
    return num/1000.0

if dis<km2m(0.1):
    vv = 0
elif dis<=km2m(5):
    vv = m2km(dis*10)
elif km2m(6) <= dis <= km2m(30):
    vv = m2km(dis)+50
elif km2m(35) <= dis <= km2m(70):
    vv = (m2km(dis)-30)/5+80
elif km2m(70) <= dis :
    vv=89

vv = int(vv)

if len(str(vv)) == 1:
    print ("0"+str(vv))
elif len(str(vv)) == 2:
    print (str(vv))