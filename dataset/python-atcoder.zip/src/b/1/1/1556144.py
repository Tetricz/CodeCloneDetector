m = int(input())
km = m / 1000
if km < 0.1:
    VV = 00
elif km <= 5:
    VV = int(km * 10)
elif km <= 30:
    VV = int(km + 50)
elif km <= 70:
    VV = int((km -30) // 5 + 80)
else:
    VV = 89
print("{0:02}".format(VV))