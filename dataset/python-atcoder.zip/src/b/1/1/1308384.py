x_m = raw_input() # x[m]
x_km = float(x_m)/1000

"""
a = raw_input('a: ')
bc = raw_input('b c:').split(' ')
print a
print bc[0]
print bc[1]
"""

if x_km < 0.1:
    VV = '00'
elif x_km >= 0.1 and x_km <= 5:
    vv = int(x_km*10)
    if vv <10:
        VV = '0' + str(vv)
    else:
        VV = str(vv)
elif x_km >= 6 and x_km <= 30:
    vv = int(x_km) + 50
    VV = str(vv)
elif x_km >= 35 and x_km <= 70:
    vv = (int(x_km) - 30)/5 + 80
    VV = str(vv)
elif x_km > 70:
    VV = '89'

print VV