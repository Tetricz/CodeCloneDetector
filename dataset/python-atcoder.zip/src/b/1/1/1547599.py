# -*- coding: utf-8 -*-
m = int(input())

if 100 > m:
    print('00')
elif 5000 >= m:
    print("{:02d}".format(m // 100))
elif 30000 >= m:
    print(m // 1000 + 50)
elif 70000 >= m:
    print((m // 1000 - 30) // 5 + 80)
else:
    print(89)
