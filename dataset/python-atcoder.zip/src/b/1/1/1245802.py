import sys

def solve():
    m = int(input())

    vv = ''

    if m < 100:
        vv = '00'
    elif m <= 5000:
        vv = str(m * 10 // 1000).zfill(2)
    elif m <= 30000:
        vv = m // 1000 + 50
    elif m <= 70000:
        vv = (m // 1000 - 30) // 5 + 80
    else:
        vv = 89

    print(vv)
    
if __name__ == '__main__':
    solve()