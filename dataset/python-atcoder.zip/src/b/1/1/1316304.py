# coding: utf-8
def get_ln_inputs():
    return input().split()


def get_ln_int_inputs():
    return list(map(int, get_ln_inputs()))


def get_vv(meter):
    if meter < 100:
        return 0
    if meter <= 5000:
        return meter // 100
    if meter <= 30000:
        return meter // 1000 + 50
    if meter <= 70000:
        return (meter // 1000 - 30) // 5 + 80
    return 89


def main():
    m = get_ln_int_inputs()[0]
    print("%02d" % get_vv(m))


main()