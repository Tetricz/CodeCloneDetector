m = int(input())
ret = None

if m < 100:
    ret = 0
elif m <= 5000:
    ret = int(m / 1000 * 10)
elif m <= 30000:
    ret = int(m / 1000 + 50)
elif m <= 70000:
    ret = int((m / 1000 - 30) / 5 + 80)
else:
    ret = 89

print('{0:02d}'.format(ret))