# -*- coding: utf-8 -*-

def main():
    m = int(input())

    # less than 0.1km
    if m < 100:
        vv = 0
    # greater than or equal to 0.1km, less than or equal to 5km
    elif 100 <= m <= 5000:
        vv = m / 1000 * 10
    # greater than or equal to 6km, less than or equal to 30km
    elif 6000 <= m <= 30000:
        vv = m / 1000 + 50
    # not less than 35km, not greater than 70km
    elif 35000 <= m <= 70000:
        vv = (m / 1000 - 30) / 5 + 80
    # greater than 70km
    elif m > 70000:
        vv = 89
    else:
        pass

    print('{:0>2}'.format(int(vv)))


if __name__ == '__main__':
    main()