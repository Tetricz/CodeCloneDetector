m = int(input())
km = m/1000
result = 0
if km<0.1:
  result=0
elif km <= 5:
  result=km*10
elif km <= 30:
  result = km+50
elif km <= 70:
  result = ((km - 30) / 5) + 80
else:
  result = 89
print("%02d" % result)