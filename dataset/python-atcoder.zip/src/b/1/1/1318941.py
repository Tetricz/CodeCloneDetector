import sys

m = int(sys.stdin.readline().strip())
l = 0

if m < 100:
    m = 0
elif 100 <= m <= 5000:
    m = m/100
elif 6000 <= m <= 30000:
    m = m/1000 + 50
elif 35000 <= m <= 70000:
    m = (m/1000-30)/5 + 80
elif 70000 < m:
    m = 89

print  "{0:02d}".format(m)
