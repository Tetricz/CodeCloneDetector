#!/usr/bin/env python
# coding:utf-8
import os, sys
import math



m = input()
m = m /1000.0
if m < 0.1:
    print "00"
elif 0.1 <= m <= 5:
    a = m*10
    print "%.2d"%a
elif 6<=m<=30:
    print int(m+50)
elif 35<=m<=70:
    print int((m-30)/5.0 + 80)
elif m>70:
    print 89