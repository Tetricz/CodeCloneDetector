# coding:utf-8

m = input()
m = int(m)
VV = 0
if m < 100:
    pass
elif 100 <= m <= 5000:
    VV = m / 100
elif 6000 <= m <= 30000:
    VV = m / 1000 + 50
elif 35000 <= m <= 70000:
    VV = (m / 1000 - 30) / 5 + 80
elif m > 70000:
    VV = 89

if VV < 10:
    print('0' + str(int(VV)))
else:
    print(int(VV))
