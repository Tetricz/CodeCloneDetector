m = int(input())
m = m / 1000

if m < 0.1:
    vv = "00"
elif m >= 0.1 and m <= 5:
    vv = int(m * 10)
    if vv < 10:
        vv = "0" + str(vv)
elif m >= 6 and m <= 30:
    vv = int(m + 50)
elif m >= 35 and m <= 70:
    vv = int((m - 30) / 5 + 80)
elif m > 70:
    vv = 89

print(vv)
