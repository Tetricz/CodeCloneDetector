num = int(input())
 
if (num < 1000):
    print('0' + str(int(num/100)))
elif (num <= 5000):
    print(str(int(num/100)))
elif (num <= 30000):
  print(str(int(num/1000) + 50))
elif (num <= 70000):
  print(str(int((int(num/1000) - 30)/5) + 80))
else:
  print('89')