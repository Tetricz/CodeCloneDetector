m = int(input())

def vv(m):
    if m < 100:
        return 0
    elif m <= 5000:
        return int(m/100)
    elif m <= 30000:
        return int(m/1000+50)
    elif m <= 70000:
        return int((m/1000-30)/5+80)
    elif 70000 < m:
        return 89

print('%02d' % vv(m))
