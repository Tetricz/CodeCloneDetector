m = int(input())
m = m / 1000

if m < 0.1:
    VV = "00"
elif m >= 0.1 and m <= 5:
    VV = m * 10
elif m >= 6 and m <= 30:
    VV = m + 50
elif m >= 35 and m <= 70:
    VV = (m - 30) / 5 + 80
elif m > 70:
    VV = "89"

print('{0:02d}'.format(int(VV)))