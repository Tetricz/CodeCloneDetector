m = int(input()) / 1000
if (m < 0.1):
    VV = 0
elif (m <= 5):
    VV = m * 10
elif (m <= 30):
    VV = m + 50
elif(m <= 70):
    VV = (m - 30) / 5 + 80
else:
    VV = 89
print("{0:02d}".format(int(VV)))

