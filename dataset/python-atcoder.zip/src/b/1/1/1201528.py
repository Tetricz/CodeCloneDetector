#!/usr/bin/env python3
# -*- coding: utf-8 -*-


def dist2vv(m):
    if m < 100:
        return 0
    elif 100 <= m <= 5000:
        return m // 100
    elif 6000 <= m <= 30000:
        return m // 1000 + 50
    elif 35000 <= m <= 70000:
        return ((m // 1000) - 30) // 5 + 80
    elif 70000 < m:
        return 89
    else:
        assert False

def main():
    m = int(input())

    vv = dist2vv(m)

    print("{:02d}".format(vv))

if __name__ == "__main__": main()
