m = int(input())
km = m / 1000
vv = 0
if(km < 0.1):
    vv = "00"
elif(0.1 <= km <= 5):
    vv = int(km * 10)
    vv = str(vv).zfill(2)
elif(6 <= km <= 30):
    vv = int(km + 50)
elif(35 <= km <= 70):
    vv = int((km - 30) / 5 +80)
elif(70 < km):
    vv = 89
print(vv)
