m=int(input())#入力
n=float(m/1000)#距離(km)
if m < 100:
    print("00")
elif m < 1000:
    print("0"+str(int(n*10)))
elif m <= 5000:
    print(str(int(n*10)))
elif m <= 30000:
    print(str(int(n+50)))
elif m <= 70000:
    print(str(int((n-30)/5+80)))
else:
    print("89")