m = int(input())

def vv(m):
    if m < 100:
        return 0
    if m <= 5000:
        return 10 * m/1000
    if m <= 30000:
        return m/1000 + 50
    if m <= 70000:
        return (m/1000 - 30)/5 + 80
    return 89

ans = int(vv(m))
if len(str(ans)) == 1:
    print("0{}".format(ans))
else:
    print(ans)
