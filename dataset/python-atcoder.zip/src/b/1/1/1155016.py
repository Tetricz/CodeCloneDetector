m = input()
k = m / 1000.0
VV = "00"
if k < 0.1:
  VV = "00"
elif k >= 0.1 and k < 1.0:
  VV = "0" + str(int(k*10))
elif k >= 1.0 and k <= 5:
  VV = str(int(k*10))
elif k >= 6 and k <= 30:
  VV = str(int(k+50))
elif k >= 35 and k <= 70:
  VV = str(int((k-30)/5+80))
elif k > 70:
  VV = "89"

print VV