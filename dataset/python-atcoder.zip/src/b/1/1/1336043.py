N = float(input())
N *= 0.001
VV = 0
if  0.1 <= N and N <= 5:
    VV = N * 10
elif 6 <= N and N <= 30:
    VV = N + 50
elif 35 <= N and N <= 70:
    VV = (N - 30) / 5 + 80
elif 70 < N:
    VV = 89
print("{0:02d}".format(int(VV)))
