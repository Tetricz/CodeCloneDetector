m = int(input())
if m < 100:
    print('00')
elif 5000 >= m:
    print('%02d' % (m / 100))
elif 30000 >= m:
   print('%02d' %(m/ 1000 + 50))
elif 70000 >= m:
   print('%02d' % ((m / 1000 - 30) / 5 + 80))
else:
    print(89)