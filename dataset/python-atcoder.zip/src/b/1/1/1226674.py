def B():
    m = int(input())
    vv = 0
    if m < 100:
        vv = 0
    elif m <= 5000:
        vv = int(m/100)
    elif m <= 30000:
        vv = int(m/1000+50)
    elif m <= 70000:
        vv = int((m/1000-30)/5+80)
    else:
        vv = 89
    print("{0:02}".format(vv))

B()