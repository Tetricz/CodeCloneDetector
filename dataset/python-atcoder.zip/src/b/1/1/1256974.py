km = (int(input()))/1000

VV = 0
if km < 0.1:
    pass
elif 0.1<=km<=5:
    VV = int(10*km)
elif 6<=km<=30:
    VV = int(km+50)
elif 35<=km<=70:
    VV = int((km-30)/5+80)
elif 70<km:
    VV = int(89)
    
print("{0:02d}".format(VV))