m = int(input())
vv = 0
if m < 100:
    vv = "00"
elif 100<= m and m <= 5000:
    n = m // 100
    if n < 10:
        vv = "0" + str(n)
    else:
        vv = str(n)
elif 6000 <= m <= 30000:
    n = m // 1000 + 50
    vv = str(n)
elif 35000 <= m <= 70000:
    n = (m//1000-30)//5+80
    vv = str(n)
elif 70000 <= m:
    vv = "89"
print(vv)
