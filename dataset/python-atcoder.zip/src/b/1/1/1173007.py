import sys

def convert(m):
    if m < 100:
        return 0
    elif m <= 5000:
        return int((m / 1000) * 10)
    elif m <   6000:
        return 0 #条件にない
    elif m <= 30000:
        return int(m / 1000) + 50
    elif m <  35000:
        return 0 #条件にない
    elif m <= 70000:
        return int((m / 1000 - 30) / 5) + 80
    else:
        return 89


for line in sys.stdin:

    m = int(line)

    ans = convert(m)
    if (ans < 10):
        print("0%d" % ans)
    else:
        print("%d" % ans)
