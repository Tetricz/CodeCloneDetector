def p2(s):
  s=str(int(s))
  while len(s) < 2: s = '0'+s
  return s
 
def f(m):
  if m < 100: return '00'
  if m <= 5000: return p2(m//100)
  if m <= 30000: return p2(((m//100)/10)+50)
  if m <= 70000: return p2(((((m//100)/10)-30)/5)+80)
  return '89'
 
m=int(input())
print(f(m))