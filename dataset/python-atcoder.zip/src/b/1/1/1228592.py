def main():
    m = int(input())

    if m < 100:
        print('00')
    elif m >= 100 and m <= 5000:
        print('{:02d}'.format(int(m / 100)))
    elif m >= 6000 and m <= 30000:
        print(int(m / 1000) + 50)
    elif m >= 35000 and m <= 70000:
        print(int((m - 30000) / 5000) + 80)
    else:
        print('89')

main()
