m=float(input())
M=m*10**(-3)
if M<0.1:
    print ("{0:0>2}".format(0))
elif 0.1<=M<=0.99:
    VV=M*10
    print ("{0:0>1}".format(0)+str(int(VV)))
elif 1<=M<=5:
     VV=M*10
     print (int(VV))
elif 6<=M<=30:
    VV=M+50
    print (int(VV))
elif 35<=M<=70:
    VV=(M-30)//5.0+80
    print (int(VV))
elif 70<=M:
    VV=89
    print (int(VV))