def vv(m):
    if m < 100:
        return "00"
    x = m/1000
    if x <= 5:
        r = "0"+(str)((int)(x*10))
        return r[len(r)-2:]
    if x <= 30:
        return (str)((int)(x)+50)
    if x <= 70:
        return (str)(((int)(x)-30)//5+80)
    return "89"


if __name__ == '__main__':
    givenm = (int)(input())
    print(vv(givenm))
