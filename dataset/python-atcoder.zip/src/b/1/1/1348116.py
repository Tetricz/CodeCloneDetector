m = int(input())
diff = m*1.0 / 1000
if diff < 0.1:
    vv = str(0).zfill(2)
elif 0.1 <= diff and diff <= 5:
    vv = str(int(diff * 10)).zfill(2)
elif 6 <= diff and diff <= 30:
    vv = str(int(diff + 50))
elif 35 <= diff and diff <= 70:
    vv = str(int((diff - 30) / 5 + 80))
elif diff > 70:
    vv = str(89)
print(vv)
