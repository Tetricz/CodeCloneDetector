def B(m):
    km = m / 1000.0
    if km < 0.1:
        VV = 0
    elif 0.1 <= km and km <= 5:
        VV = km * 10
    elif 6 <= km and km <= 30:
        VV = km + 50
    elif 35 <= km and km <= 70:
        VV = (km - 30) / 5 + 80
    elif 70 < km:
        VV = 89

    import math
    VV = str(round(VV)).zfill(2)
    return VV

m=int(input())
print(B(m))