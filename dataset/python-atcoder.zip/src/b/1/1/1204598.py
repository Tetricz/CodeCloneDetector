a=int(input())
if a<100:
  print ("00")
elif a<=5000:
  print ("{0:0>2}".format(int(a/100)))
elif a<=30000:
  print (int((a/1000) + 50))
elif a<=70000:
  print (int((((a/1000) - 30) /5) +80))
elif a>70000:
  print (89)
else:
  print("ERROR")