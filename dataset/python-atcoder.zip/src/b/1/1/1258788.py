m = int(input())
km = m/1000
if km < 0.1:
    vv = 0
elif 0.1 <= km <= 5:
    vv = km * 10
elif 6 <= km <= 30:
    vv = km + 50
elif 35 <= km <= 70:
    vv = (km - 30)//5 +80
elif km > 70:
    vv = 89

ans = int(vv)
if len(str(ans)) != 2:
    print("0" + str(ans))
else:
    print(ans)

